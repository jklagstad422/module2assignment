package edu.wctc.interfaces;

import edu.wctc.Player;

public interface Exitable {
    String exit(Player player);
}
