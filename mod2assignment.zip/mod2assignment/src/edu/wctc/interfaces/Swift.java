package edu.wctc.interfaces;

public interface Swift {
    void useSwiftAbility();
}
