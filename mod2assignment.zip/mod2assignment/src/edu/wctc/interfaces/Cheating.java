package edu.wctc.interfaces;

public interface Cheating {
    void useCheat();
}

