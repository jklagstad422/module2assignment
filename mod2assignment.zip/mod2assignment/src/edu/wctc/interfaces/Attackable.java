package edu.wctc.interfaces;
import edu.wctc.Player;

public interface Attackable {
    String attack(Player player);
}
