package edu.wctc.interfaces;

import edu.wctc.Player;

public interface Lootable {
    String loot(Player player);
}
