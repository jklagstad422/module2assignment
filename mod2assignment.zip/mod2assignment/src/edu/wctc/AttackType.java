package edu.wctc;

public enum AttackType {
    SLASH,
    PIERCE,
    MAGIC,
    HEAL
}
