package edu.wctc;

import java.util.Scanner;

public class Game {
    public void run() {
        System.out.println("Running the old game...");
        Scanner scanner = new Scanner(System.in);
        System.out.println("Old game: Enter something to continue...");
        scanner.nextLine();
        System.out.println("Old game ended.");
    }
}
